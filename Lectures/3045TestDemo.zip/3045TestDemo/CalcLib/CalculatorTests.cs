﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace CalcLib
{
    [TestFixture]
    class CalculatorTests
    {
        [Test]
        public void Test_Add()
        {
            Calculator calc = new Calculator();
            int answer = calc.Add(2, 2);
            Assert.AreEqual(10, answer);
        }

        [Test]
        public void Test_Subtract()
        {
            Calculator calc = new Calculator();
            int answer = calc.Subtract(2, -2);
            Assert.AreEqual(4, answer);
        }

        [Test]
        public void Test_Multiply()
        {
            Calculator calc = new Calculator();
            int answer4 = calc.Multiply(2, 2);
            Assert.AreEqual(4, answer4);
        }

        [Test]
        public void Test_Divide()
        {
            Calculator calc = new Calculator();
            int answer = calc.Divide(2, 2);
            Assert.AreEqual(1, answer);
        }

        [Test]
        [ExpectedException(typeof(OverflowException))]
        public void Test_AddShouldThrowOverFlowException()
        {
            Calculator calc = new Calculator();

            Assert.AreEqual(1, calc.Add(int.MaxValue, 1));
        }


    }

}
