﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CalcLib;

namespace CSTestDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            txtResult.Text = calc.Add(Int32.Parse(txtNum1.Text), Int32.Parse(txtNum2.Text)).ToString();
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            txtResult.Text = calc.Subtract(Int32.Parse(txtNum1.Text), Int32.Parse(txtNum2.Text)).ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            txtResult.Text = calc.Multiply(Int32.Parse(txtNum1.Text), Int32.Parse(txtNum2.Text)).ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            txtResult.Text = calc.Divide(Int32.Parse(txtNum1.Text), Int32.Parse(txtNum2.Text)).ToString();
        }

     
    }
}
